package com.shashi.constant;

public enum UserRole {
	ADMIN, CUSTOMER
}
